import { initializeApp } from "firebase/app";
import {getAuth , GoogleAuthProvider , signInWithEmailAndPassword, signInWithEmailLink, signInWithPopup} from 'firebase/auth';
const firebaseConfig = {
  apiKey: "AIzaSyCVqQWx0BXaYjtxrxc5LXczNUusceJHOok",
  authDomain: "canteen-2.firebaseapp.com",
  projectId: "canteen-2",
  storageBucket: "canteen-2.appspot.com",
  messagingSenderId: "809217911829",
  appId: "1:809217911829:web:0138298b8b01322da3721c"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

export const provider = new GoogleAuthProvider();

export const signInWithGoogle = () =>{
signInWithPopup(auth,provider)
.then((result)=>{
  console.log(result);
console.log(result);
const name = result.user.displayName;
const email = result.user.email;
const profilePic = result.user.photoURL;
const phone = result.user.phoneNumber;
const AccountCreation = result.user.metadata.creationTime;
const emailVerified = result.user.emailVerified;

localStorage.setItem("name", name);
localStorage.setItem("email",email);
localStorage.setItem("photo" , profilePic);
localStorage.setItem("phone" , phone);
localStorage.setItem("AccountCreation" , AccountCreation);
localStorage.setItem("AccountCreation" , AccountCreation);
localStorage.setItem("EmailVerification" , emailVerified);
}).catch((err)=>{
    alert('Error Signing in ')
})
}

