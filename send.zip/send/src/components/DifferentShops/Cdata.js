export const Cdata =[{
    "id":11,
    "name":"Triple Chicken Feast",
    "veg":false,
    "type":"non-veg",
    "price":629,
    "description":"Schezwan Chicken Meatball Herbed Chicken,Chicken Sausage,Geen Capsicum, Onion,Red Paprika",
    "quantity":1,
    "img":"https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/triple-chicken-feast.21e57422a5579843b4722a067fbda8ca.1.jpg?width=522"
    },
    {
    "id":12,
    "name":"Chicken Tikka",
    "veg":false,
    "type":"non-veg",
    "price":569,
    "description":"Chicken Tikka, Onion, Tomato",
    "quantity":1,
    "img":"https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/chicken-tikka.4e3ef28838886936da1a2280543cfae8.1.jpg?width=522"
    },
    {
    "id":13,
    "name":"Double Chicken Sausage",
    "veg":false,
    "type":"non-veg",
    "price":529,
    "description":"Chicken Sausage",
    "quantity":1,
    "img":"https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/double-chicken-sausage.27693ba787c68a763bb3f0e397de0019.1.jpg?width=522"
    },
    {
      "id": 14,
      "name": "Choco Volcano Cake",
      "price": 99,
      "type":"veg",
      "description": "Choco Delight With A Gooey Chocolate Volcano Centre",
      "img": "https://api.pizzahut.io/v1/content/en-in/in-1/images/dessert/choco-volcano-cake.dd9f24941b09268c73c073494d54480d.1.jpg?width=522",
      "quantity": 1
   },
    {
    "id":15,
    "name":"Spiced Chicken Meatballs",
    "veg":false,
    "type":"non-veg",
    "price":469,
    "description":"Schezwan Chicken Meatball Onion",
    "quantity":1,
    "img":"https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/spiced-chicken-meatballs.fcb515f6af388d6e30df81ca2968798c.1.jpg?width=522"
    },
    {
    "id":16,
    "name":"Double Cheese",
    "veg":true,
    "type":"veg",
    "price":419,
    "description":"Extra Cheese on Cheese",
    "quantity":1,
    "img":"https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/double-cheese.f8ac8046d97de45670aa7d41b5cf8db6.1.jpg?width=522"
    },
    {
        "id": 17,
        "name": "Choco Sundae",
        "type":"veg",
        "price": 29,
        "description": "Choco Sundae Cup (100 ml)",
        "img": "https://api.pizzahut.io/v1/content/en-in/in-1/images/dessert/choco-sundae.e0d29fd156012e251c099c2771219d18.1.jpg?width=800",
        "quantity": 100
     }]