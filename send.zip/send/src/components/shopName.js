export const shops = [
    {
        "name" : "A",
        "photo" :"https://d1hy6t2xeg0mdl.cloudfront.net/image/91359/20d19cebcd/standard",
        "food": "Vegetarian | Non-Vegetarian",
        "link" : "/A"
        
    },
    {
        "name" : "B",
        "photo" :"https://content3.jdmagicbox.com/comp/mumbai/w5/022pxx22.xx22.160419142459.j9w5/catalogue/snack-anytime-mulund-west-mumbai-farsan-shops-7zjlf1.jpg?clr=2c3a2c",
        "food": "Vegetarian ",
        "link" : "/B"

        
    },
    {
        "name" : "C",
        "photo" :"https://sc04.alicdn.com/kf/HTB19DExRFXXXXbQaXXXq6xXFXXXo.jpg",
        "food": "Vegetarian | Non-Vegetarian",
        "link" : "/C"

        
    },

]