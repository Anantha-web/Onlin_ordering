export const addonData = [ {
    "name" : "Cheese Dip",
    "price" : 50,
    "id" :1,
    "img" : "https://www.budgetbytes.com/wp-content/uploads/2016/02/5-Minute-Nacho-Cheese-Sauce-dip3-1-500x480.jpg",
    "description":"Mozrella Cheese for the Nacho's you have",
    "type":"veg"


},
{
    "name" : "Sauce",
    "price" : 30,
    "id" :2,
    "img" : "https://upload.wikimedia.org/wikipedia/commons/5/52/Fresh_Tomato_Sauce_%28Unsplash%29.jpg",
    "description":"Extra sauce ",
    "type":"veg"



},
{

    "name" : "Coke",
    "price" : 30,
    "id" :3,
    "img" : "https://cdn-a.william-reed.com/var/wrbm_gb_food_pharma/storage/images/publications/food-beverage-nutrition/beveragedaily.com/article/2019/07/12/diet-coke-helps-boost-coca-cola-s-brand-value-brand-finance-rankings/9912727-1-eng-GB/Diet-Coke-helps-boost-Coca-Cola-s-brand-value-Brand-Finance-rankings_wrbm_large.jpg",
    "description":"300ml",
    "type":"veg"

},
{
    "name" : "Choco Lava",
    "price" : 100,
    "id" :4,
    "img" : "https://imagesvc.meredithcorp.io/v3/mm/image?q=85&c=sc&poi=face&w=1667&h=834&url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F9%2F2013%2F12%2F06%2Fmolten-chocolate-cake-FT-RECIPE0220.jpg",
    "description" : "Choco Lava cake ",
    "type":"non-veg"


}]